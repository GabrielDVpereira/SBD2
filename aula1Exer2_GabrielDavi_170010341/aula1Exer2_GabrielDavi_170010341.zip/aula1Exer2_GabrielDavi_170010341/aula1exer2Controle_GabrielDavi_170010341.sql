insert into Supervisiona(cpf_gerente, cpf_empregado) VALUES 
    ('00000000000', '11111111111'),
    ('00000000000', '22222222222');