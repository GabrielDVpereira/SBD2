USE db;

DROP TABLE Pessoa;
DROP TABLE Gerente;
DROP TABLE Empregado;
DROP TABLE Contato;
DROP TABLE Supervisiona;
DROP TABLE Produto;
DROP TABLE Venda;
